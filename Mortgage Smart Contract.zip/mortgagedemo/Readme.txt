# mortgage-blockchain-demo
An illustrative DApp to address a potential use case in the mortgage space; Smart contracts can automate mortgage contracts by automatically connecting the parties, providing for a frictionless and less error-prone process. The smart contract can automatically process payment and release liens from land records when the loan is paid.


## Setup 
- npm install -g ganache 
- npm install -g truffle
- mkdir demo
- cd demo
- npm install
- truffle compile
- truffle migragte
- npm run dev

- Access application - http://localhost:8080

